1. The data file "diabetes.csv" contains data of 768 patients. In this data there are 8 attributes (Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, and Age) and 1 response variable (Outcome). The response variable, Outcome, has binary value (1 indicating the outcome is diabetes and 0 means no diabetes),we considered whole data as population for our analysis

a. At first we created a sample of size 25 form the population and find the mean Glucose and highest Glucose values of this sample and compare these statistics with the population statistics of the same variable. Created a bar plot and pie chart for visual representation of comparison. 
 

b. Then found the 98th percentile of BMI of your sample and the population and compare the results using charts (bar and pie)

c. Using bootstrap (replace= True), created 500 samples (of 150 observation each) from the population and found the average mean, standard deviation and percentile for BloodPressure and compare this with these statistics from the population for the same variable, and created charts(bar and pie) for this comparison.

All the results where saved under results folder.
