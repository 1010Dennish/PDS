1. The data file "diabetes.csv" contains data of 768 patients. In this data there are 8 attributes (Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, and Age) and 1 response variable (Outcome). The response variable, Outcome, has binary value (1 indicating the outcome is diabetes and 0 means no diabetes),we considered whole data as population for our analysis

a) In order to compare these statistics with the population statistics for the same variable, we first created a sample of size 25 from the population and determined its mean and highest glucose values. made a bar plot and a pie chart to show comparisons visually.
 

b) Then found the 98th percentile of BMI of your sample and the population and compare the results using charts (bar and pie)

c) The average mean, standard deviation, and percentile for BloodPressure were determined using bootstrap (replace=True), 500 samples (of 150 observations each) from the population were created, and these statistics were compared with those from the population for the same variable, and charts (bar and pie) were created for this comparison.

All the results where saved under results folder.
